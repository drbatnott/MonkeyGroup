Demo scenes require Unity Standard Assets (Effects) package installed.

Installation:
Assets -> Import Package -> Effects