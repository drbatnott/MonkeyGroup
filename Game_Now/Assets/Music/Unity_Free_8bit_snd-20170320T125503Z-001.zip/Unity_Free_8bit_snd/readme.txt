Dear customers

Thank you so much for your support.

Here're 16 pieces of sound effect for 8bit games, all in WAV format.

Although we tried hard to provide the exact name for each sound effect, 
it could be a mistake. We apologize for any inconvenience.

Best regards,
XHertz ( From Strange Pulse Studio )
Our Google Play Store : https://play.google.com/store/apps/developer?id=Pulse


